import {SORT_VGAMES} from '.';

export default function sortvgames(payload) {
    return {
        type: SORT_VGAMES,
        payload
    }
}